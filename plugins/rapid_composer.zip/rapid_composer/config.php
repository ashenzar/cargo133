<?php

define( 'RC_COMPATIBILITY_MODE', true );